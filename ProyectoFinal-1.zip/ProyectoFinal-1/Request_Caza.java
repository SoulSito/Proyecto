package ProyectPro;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Request_Caza {
    private static final String TUTORIAL_FILE_PATH = "F:/ProyectoFinal-1/Monsters.txt";

    public static String Lista_caza(int lineNumber) {
        String line = "";
        try (BufferedReader reader = new BufferedReader(new FileReader(TUTORIAL_FILE_PATH))) {
            int currentLine = 1;
            String currentLineContent;
            while ((currentLineContent = reader.readLine())!= null) {
                if (currentLine == lineNumber) {
                    line = currentLineContent;
                    break;
                }
                currentLine++;
            }
        } catch (IOException e) {
            // Log the exception or throw a custom exception
            System.err.println("Error reading tutorial file: " + e.getMessage());
        }
        return line;
    }
}
