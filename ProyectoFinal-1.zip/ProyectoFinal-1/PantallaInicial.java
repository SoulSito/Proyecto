package ProyectPro;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class PantallaInicial {

    JFrame frame_PantallaInicial;
    JLabel texto_label, texto;
    String linea = "<html>Bienvenido cazador aqui te dejo una lista de los Monstruos de hoy.</html>";
    
    int frame = 0;
    int num_tuto = 0;
   
    public PantallaInicial() {
    	frame_PantallaInicial = new JFrame("MHW");
    	frame_PantallaInicial.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a custom JPanel with a background image
        Panel_1 PantallaInicial = new Panel_1("F:/ProyectoFinal-1/Fondo1.jpg");
        frame_PantallaInicial.setContentPane(PantallaInicial);

        GridBagLayout layout = new GridBagLayout();
        frame_PantallaInicial.setLayout(layout);
        
        ImageIcon texto = new ImageIcon("F:/ProyectoFinal-1/Texto.png");
        Image texto_image = texto.getImage();
        ImageIcon texto_scaled = new ImageIcon(texto_image.getScaledInstance(900, 500, Image.SCALE_SMOOTH)); 
        
        texto_label = new JLabel();
		texto_label.setIcon(texto_scaled);
        
        frame_PantallaInicial.setBounds(100, 100, 1200, 672);
        

        Acciones(PantallaInicial);
        frame_PantallaInicial.setResizable(false);
        frame_PantallaInicial.setVisible(true);
    }
    
    private void Acciones(JPanel panel) {
    	ImageIcon avanzar_tuto = new ImageIcon("F:/ProyectoFinal-1/Boton5.png");
        Image avanzar_tuto_image = avanzar_tuto.getImage();
        ImageIcon avanzar_tuto_scaled = new ImageIcon(avanzar_tuto_image.getScaledInstance(100, 100, Image.SCALE_SMOOTH));
    	JButton avanzar_tutorial = new JButton();
    	avanzar_tutorial.setIcon(avanzar_tuto_scaled);
    	avanzar_tutorial.setFocusPainted(false);
    	avanzar_tutorial.setBorderPainted(false);
    	avanzar_tutorial.setContentAreaFilled(false);
    	
    	ImageIcon retroceder_tuto = new ImageIcon("F:/ProyectoFinal-1/Boton4.png");
        Image retroceder_tuto_image = retroceder_tuto.getImage();
        ImageIcon retroceder_tuto_scaled = new ImageIcon(retroceder_tuto_image.getScaledInstance(100, 100, Image.SCALE_SMOOTH));
    	JButton retroceder_tutorial = new JButton();
    	retroceder_tutorial.setIcon(retroceder_tuto_scaled);
    	retroceder_tutorial.setFocusPainted(false);
    	retroceder_tutorial.setBorderPainted(false);
    	retroceder_tutorial.setContentAreaFilled(false);
    	retroceder_tutorial.setEnabled(false);
    	
    	ImageIcon cerrar_tuto = new ImageIcon("F:/ProyectoFinal-1/Boton3.png");
        Image cerrar_tuto_image = cerrar_tuto.getImage();
        ImageIcon cerrar_tuto_scaled = new ImageIcon(cerrar_tuto_image.getScaledInstance(100, 100, Image.SCALE_SMOOTH));
    	JButton cerrar_tutorial = new JButton();
    	cerrar_tutorial.setIcon(cerrar_tuto_scaled);
        cerrar_tutorial.setFocusPainted(false);
        cerrar_tutorial.setBorderPainted(false);
        cerrar_tutorial.setContentAreaFilled(false);
        
        ImageIcon cambiarpanel = new ImageIcon("F:/ProyectoFinal-1/Boton1.png");
        Image cambiarpanel_image = cambiarpanel.getImage();
        ImageIcon cambiarpanel_scaled = new ImageIcon(cambiarpanel_image.getScaledInstance(100, 100, Image.SCALE_SMOOTH));
    	JButton cambiarpanel2 = new JButton();
    	cambiarpanel2.setIcon(cambiarpanel_scaled);
    	cambiarpanel2.setFocusPainted(false);
    	cambiarpanel2.setBorderPainted(false);
    	cambiarpanel2.setContentAreaFilled(false);
        
    	texto = new JLabel(linea);
    	texto.setForeground(Color.BLACK);
    	Font textofont = new Font("Cartograf", Font.PLAIN, 20);
    	texto.setFont(textofont);

    	texto_label.setLayout(new BorderLayout());
    	texto_label.add(texto, BorderLayout.CENTER);
    	texto_label.add(avanzar_tutorial, BorderLayout.EAST); 	
    	texto_label.add(retroceder_tutorial, BorderLayout.WEST);
    	texto_label.add(cerrar_tutorial, BorderLayout.EAST);
    	texto_label.add(cambiarpanel2, BorderLayout.WEST);
    	
        GridBagConstraints texto_position = new GridBagConstraints();
        texto_position.gridx = 1; // column
        texto_position.gridy = 1; // row
        texto_position.anchor = GridBagConstraints.NORTHEAST; // position
        texto_position.insets = new Insets(500, 0, 0, 0); // top, left, bottom, right margins

        panel.add(texto_label, texto_position);

        avanzar_tutorial.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				retroceder_tutorial.setEnabled(true);
				num_tuto ++;
				linea = "<html>" + Request_Caza.Lista_caza(num_tuto) +"</html>";
				if (Request_Caza.Lista_caza(num_tuto + 1).length() == 0) {
					avanzar_tutorial.setEnabled(false);
				}
				linea = "<html>" + Request_Caza.Lista_caza(num_tuto) +"</html>";
				texto.setText(linea);
				frame_PantallaInicial.repaint();
			}
        	
        });
           
        retroceder_tutorial.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				avanzar_tutorial.setEnabled(true);
				if (num_tuto > 1) {
					num_tuto --;
					linea = "<html>" + Request_Caza.Lista_caza(num_tuto) +"</html>";
				} else if (num_tuto == 1) {
					num_tuto --;
					retroceder_tutorial.setEnabled(false);
					linea = "<html>Bienvenido cazador aqui te dejo una lista de los Monstruos de hoy.</html>";
				} else {
					
				}
				texto.setText(linea);
				frame_PantallaInicial.repaint();
			}
        	
        });
        
        cerrar_tutorial.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
            
            
            
        });
        cambiarpanel2.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		new PantallaInsersion(); 
        		frame_PantallaInicial.dispose(); // Cierra la ventana actual
        		// Crea una nueva instancia de la pantalla de inserción
        	}
        });
        
        JPanel panelBotones = new JPanel();
        panelBotones.setOpaque(false);
        panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
        panelBotones.add(avanzar_tutorial);
        panelBotones.add(cerrar_tutorial);

        texto_label.setLayout(new BorderLayout());
        texto_label.add(texto, BorderLayout.CENTER);
        texto_label.add(panelBotones, BorderLayout.EAST);
        
        JPanel panelBotones2 = new JPanel();
        panelBotones2.setOpaque(false);
        panelBotones2.setLayout(new BoxLayout(panelBotones2, BoxLayout.X_AXIS));
        panelBotones2.add(cambiarpanel2);
        panelBotones2.add(retroceder_tutorial);

        texto_label.setLayout(new BorderLayout());
        texto_label.add(texto, BorderLayout.CENTER);
        texto_label.add(panelBotones, BorderLayout.EAST);
        texto_label.add(panelBotones2, BorderLayout.WEST);
}
    
    protected Component getRootPane() {
	// TODO Auto-generated method stub
	return null;
}
private void cambiarPanel() {
        
    }
    
    public static void main(String[] args) {
        new PantallaInicial();
    }
}

class Panel_1 extends JPanel {
    private Image image;

    public Panel_1(String imgPath) {
        try {
            image = ImageIO.read(new File(imgPath));
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), null);
    }

}

    