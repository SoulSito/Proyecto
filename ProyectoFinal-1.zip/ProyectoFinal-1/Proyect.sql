Drop Database IF EXISTS proyecto;
CREATE DATABASE IF NOT EXISTS Proyecto;
USE Proyecto;

CREATE TABLE IF NOT EXISTS Monsters(
    Id_Mons NUMERIC(4,0) Primary Key DEFAULT 12,
    Nombre_Mons VARCHAR(100),
    Habitad_Mons VARCHAR(100)
    );
    INSERT INTO Monsters VALUES(1, 'Kulu-Yaku', 'Bosque');
    INSERT INTO Monsters VALUES(2, 'Deviljho', 'Cualquiera');
    INSERT INTO Monsters VALUES(3, 'Mitzusune', 'Pantano');
    INSERT INTO Monsters VALUES(4, 'Gore-Magala', 'Cualquiera');
    INSERT INTO Monsters VALUES(5, 'Fatalis', 'Cualquiera');
    INSERT INTO Monsters VALUES(6, 'Rathian', 'Bosque');
    INSERT INTO Monsters VALUES(7, 'Pukei-Pukei', 'Bosque');
    INSERT INTO Monsters VALUES(8, 'Rathalos', 'Bosque');
    INSERT INTO Monsters VALUES(9, 'Zinogre', 'Paramo Helado');
    INSERT INTO Monsters VALUES(10, 'Velkana', 'Paramo Helado');
    INSERT INTO Monsters VALUES(11, 'Legiana', 'Paramo Helado');