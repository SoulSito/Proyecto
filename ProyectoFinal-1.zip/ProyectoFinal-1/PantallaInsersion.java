package ProyectPro;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class PantallaInsersion {
    private JFrame frame;
    private JTable table;
    private JScrollPane scrollPane;

    public PantallaInsersion() {
        frame = new JFrame("MHW");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a custom JPanel with a background image
        Panel_1 PantallaInicial = new Panel_1("F:/ProyectoFinal-1/Fondo1.jpg");
        frame.setContentPane(PantallaInicial);

        // Ajusta el tamaño de la ventana
        frame.setBounds(100, 100, 1200, 672);

        try {
            createAndShowGUI();
            frame.setVisible(true);
            frame.setLocationRelativeTo(null);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error connecting to database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void createAndShowGUI() throws SQLException {
        TablaMons TablaMons = new TablaMons();
        Statement stmt = TablaMons.getConnection().createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Id_Mons, Nombre_Mons, Habitad_Mons FROM Monsters");

        String[] columnNames = {"Id_Mons", "Nombre_Mons", "Habitad_Mons"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        while (rs.next()) {
            int id = rs.getInt("Id_Mons");
            String nombre = rs.getString("Nombre_Mons");
            String casa = rs.getString("Habitad_Mons");

            Object[] row = {id, nombre, casa};
            model.addRow(row);
        }

        table = new JTable(model) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component c = super.prepareRenderer(renderer, row, column);
                c.setBackground(new Color(0, 0, 0, 0)); // transparent background
                return c;
            }
        };
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int rowIndex = table.rowAtPoint(e.getPoint());
                    if (rowIndex >= 0) {
                        int id = (int) table.getValueAt(rowIndex, 0);
                        String nombre = (String) JOptionPane.showInputDialog(frame, "Enter new name:", "Change Name", JOptionPane.PLAIN_MESSAGE, null, null, (String) table.getValueAt(rowIndex, 1));
                        if (nombre != null) {
                            try (PreparedStatement pstmt = TablaMons.getConnection().prepareStatement("UPDATE Monsters SET Nombre_Mons = ? WHERE id = ?")) {
                                pstmt.setString(1, nombre);
                                pstmt.setInt(2, id);
                                pstmt.executeUpdate();

                                table.setValueAt(nombre, rowIndex, 1);
                            } catch (SQLException ex) {
                                JOptionPane.showMessageDialog(frame, "Error changing name: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                }
            }
        });
        scrollPane = new JScrollPane(table) {
            @Override
            public void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 0)); // transparent background
                g.fillRect(0, 0, 0 , 0 );
                super.paintComponent(g);
            }
        };
        frame.add(scrollPane, BorderLayout.CENTER);

        JButton addButton = new JButton("AÑADIR");
        addButton.addActionListener(e -> {
            String nombre = JOptionPane.showInputDialog(frame, "Introduce nombre:");
            String casa = JOptionPane.showInputDialog(frame, "Introduce habitad:");

            try (PreparedStatement pstmt = TablaMons.getConnection().prepareStatement("INSERT INTO Monsters (Nombre_Mons, Habitad_Mons) VALUES (?, ?)")) {
                pstmt.setString(1, nombre);
                pstmt.setString(2, casa);
                pstmt.executeUpdate();

                model.addRow(new Object[]{model.getRowCount() + 1, nombre, casa});
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error adding score: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton deleteButton = new JButton("ELIMINAR");
        deleteButton.addActionListener(e -> {
            int rowIndex = table.getSelectedRow();

            if (rowIndex >= 0) {
                int id = (int) table.getValueAt(rowIndex, 0);

                try (PreparedStatement pstmt = TablaMons.getConnection().prepareStatement("DELETE FROM Monsters WHERE Id_Mons = ?")) {
                    pstmt.setInt(1, id);
                    pstmt.executeUpdate();

                    model.removeRow(rowIndex);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(frame, "Error deleting score: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a row to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        frame.add(buttonPanel, BorderLayout.EAST);

    }
    private static class TablaMons {
        private Connection connection;

         public TablaMons() throws SQLException {
             String url = "jdbc:mysql://127.0.0.1:3306/Proyecto";
             String user = "root";
             String password = "";

             connection = DriverManager.getConnection(url, user, password);
         }

         public Connection getConnection() {              
             return connection;
         }
     }

     public static void main(String[] args) {
         SwingUtilities.invokeLater(() -> {
             PantallaInsersion app = new PantallaInsersion();
         });
     }
 }